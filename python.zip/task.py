import pandas as pd
import matplotlib.pyplot as plt

def row5(starbucks):
    #星巴克数据中前五行的数据
    pd.set_option('display.max_columns', None) # 显示完整的列
    print("前五行数据：")
    print(starbucks.head())
    #星巴克旗下的品牌
    print("星巴克旗下的品牌有：\n",starbucks.Brand.value_counts())

def howmany(starbucks):

    #只查看星巴克的数据集
    coffee = starbucks[starbucks.Brand=='Starbucks']

    country = coffee.groupby(["Country"]).size()
    print("全世界开设星巴克的国家有：",country.size,"个")

    country1 = country.sort_values(ascending=False)
    print("排名前十的国家有：\n",country1.head(10))
    print("排名倒十的国家有：\n",country1.tail(10))

    city = coffee.groupby(["City"]).size()
    print("全世界开设星巴克的城市有：",city.size,"个")

    city1 = city.sort_values(ascending=False)
    print("排名前十的城市有：\n",city1.head(10))
    print("排名倒十的城市有：\n",city1.tail(10))

    china = coffee.loc[coffee['Country']=="CN"]
    china = china.groupby(["City"]).size()
    china = china.sort_values(ascending=False)

    labe_country = '世界'
    labe_china   = '中国'
    labe1 = '国家或地区'
    labe2 = '城市'
    zhuzhuangtu(country1, labe_country,labe1)
    zhuzhuangtu(city1, labe_country, labe2)
    zhuzhuangtu(china, labe_china, labe2)

def zhuzhuangtu(data, labe1, labe2):


    plt.figure(figsize=(10, 10))
    plt.bar(range(10), data.head(10), width=0.5)
    plt.xlabel(labe2)
    plt.ylabel('星巴克门店数量')
    plt.xticks(range(10), data.head(10).index)
    plt.title(f'{labe1}星巴克门店数量排名前十的{labe2}的柱状图')

    plt.savefig(f'{labe1}星巴克门店数量排名前十的{labe2}的柱状图.png')
    plt.show()
    plt.close()


def bingtu(starbucks):
    coffee = starbucks[starbucks.Brand == 'Starbucks']
    type = coffee.groupby(["Ownership Type"]).size()
    type =type.sort_values(ascending=False)
    print(type)
    plt.figure(figsize=(10, 10))

    explode = [0.1, 0.1, 0.2, 0.2]
    plt.pie(type, explode=explode, labels=type.index, autopct='%1.1f%%')
    plt.title('星巴克门店的经营方式饼状图')

    plt.savefig('星巴克门店的经营方式饼状图.png')
    plt.show()
    plt.close()


if __name__ == "__main__":
    plt.rcParams['font.sans-serif'] = ['SimHei']  # z这个好用,解决中文乱码
    plt.rcParams['axes.unicode_minus'] = False

    starbucks = pd.read_csv('data/directory.csv')

    howmany(starbucks)
    row5(starbucks)
    bingtu(starbucks)
